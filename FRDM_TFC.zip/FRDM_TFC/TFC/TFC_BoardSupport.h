#include <stdint.h>

#ifndef TFC_BOARDSUPPORT_H_
#define TFC_BOARDSUPPORT_H_


void    TFC_InitGPIO();


#endif /* TFC_BOARDSUPPORT_H_ */
